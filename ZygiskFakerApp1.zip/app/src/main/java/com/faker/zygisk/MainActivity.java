
package com.faker.zygisk;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.util.Log;
import java.io.DataOutputStream;
import java.util.Random;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "FakerApp";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button changeInfoButton = findViewById(R.id.change_info);
        changeInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeDeviceInfo();
            }
        });
    }

    private void changeDeviceInfo() {
        String androidID = generateRandomString(16);
        String deviceModel = getRandomDeviceModel();
        String manufacturer = getRandomManufacturer();
        String macAddress = getRandomMac();

        executeCommand("su -c 'settings put secure android_id " + androidID + "'");
        executeCommand("su -c 'setprop ro.product.model " + deviceModel + "'");
        executeCommand("su -c 'setprop ro.product.manufacturer " + manufacturer + "'");
        executeCommand("su -c 'echo " + macAddress + " > /sys/class/net/wlan0/address'");

        Log.d(TAG, "카카오톡 관련 모든 정보 변경 완료!");
    }

    private void executeCommand(String command) {
        try {
            Process su = Runtime.getRuntime().exec("su");
            DataOutputStream outputStream = new DataOutputStream(su.getOutputStream());
            outputStream.writeBytes(command + "\n");
            outputStream.writeBytes("exit\n");
            outputStream.flush();
            su.waitFor();
        } catch (Exception e) {
            Log.e(TAG, "명령 실행 중 오류 발생: " + e.getMessage());
        }
    }

    private String generateRandomString(int length) {
        String chars = "0123456789ABCDEF";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }

    private String getRandomDeviceModel() {
        String[] models = {"SM-G998N", "Pixel 6", "Xiaomi Mi 11", "OnePlus 9", "Galaxy Note 20"};
        return models[new Random().nextInt(models.length)];
    }

    private String getRandomManufacturer() {
        String[] manufacturers = {"Samsung", "Google", "Xiaomi", "OnePlus", "Sony"};
        return manufacturers[new Random().nextInt(manufacturers.length)];
    }

    private String getRandomMac() {
        Random random = new Random();
        return String.format("%02X:%02X:%02X:%02X:%02X:%02X",
                random.nextInt(256), random.nextInt(256), random.nextInt(256),
                random.nextInt(256), random.nextInt(256), random.nextInt(256));
    }
}
