package com.example.myhook;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.XposedBridge;

public class MyHookModule implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("com.towneers.www")) return;

        XposedBridge.log("당근마켓 후킹 시작: " + lpparam.packageName);

        // BuildConfig.VERSION_NAME 확인
        try {
            String versionName = (String) XposedHelpers.getStaticObjectField(
                XposedHelpers.findClass("com.towneers.www.BuildConfig", lpparam.classLoader),
                "VERSION_NAME"
            );
            XposedBridge.log("당근마켓 BuildConfig.VERSION_NAME: " + versionName);
        } catch (Throwable e) {
            XposedBridge.log("BuildConfig.VERSION_NAME 후킹 실패: " + e.getMessage());
        }

        // getPackageInfo() 후킹하여 확인
        XposedHelpers.findAndHookMethod(
            "android.app.ApplicationPackageManager",
            lpparam.classLoader,
            "getPackageInfo",
            String.class, int.class,
            new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log("getPackageInfo() 호출됨: " + param.args[0]);
                }

                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    if (param.args[0].equals("com.towneers.www")) {
                        Object packageInfo = param.getResult();
                        String version = (String) XposedHelpers.getObjectField(packageInfo, "versionName");
                        XposedBridge.log("당근마켓 getPackageInfo().versionName: " + version);
                    }
                }
            }
        );
    }
}